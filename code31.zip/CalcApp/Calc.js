window.addEventListener("load", initEvents);

var firstName;
var secondName;
var result = 0;

function initEvents()
{
    firstName = document.getElementById("f_num");
    secondName = document.getElementById("s_num");

    buttons = document.getElementsByTagName("button");
    for(var i = 0; i < buttons.length; i++)
    {
        buttons[i].addEventListener('click', calc);
    }


    // document.getElementById("add").addEventListener('click', calc); // this - current object/instance
    // document.getElementById("sub").addEventListener('click', calc); // this
    // document.getElementById("div").addEventListener('click', calc); // this
    // document.getElementById("mul").addEventListener('click', calc); // this

    // document.getElementById("add").addEventListener('click', add);
    // document.getElementById("sub").addEventListener('click', sub);
    // document.getElementById("div").addEventListener('click', div);
    // document.getElementById("mul").addEventListener('click', mul);
}

function calc(evt)
{
    // event.srcElement.innerHTML; ->deprecated
    var opr = evt.srcElement.innerHTML;
    //console.log(opr);
    var expression = firstName.value + opr + secondName.value;
    var result = eval(expression);
    document.getElementById("result").innerHTML = result;
}

// function add()
// {
//     result = parseInt(firstName.value) + parseInt(secondName.value);
//     document.getElementById("result").innerHTML = result;
// }

// function sub()
// {
//     result = parseInt(firstName.value) - parseInt(secondName.value);
//     document.getElementById("result").innerHTML = result;
// }

// function div()
// {
//     result = parseInt(firstName.value) / parseInt(secondName.value);
//     document.getElementById("result").innerHTML = result;
// }

// function mul()
// {
//     result = parseInt(firstName.value) * parseInt(secondName.value);
//     document.getElementById("result").innerHTML = result;
// }