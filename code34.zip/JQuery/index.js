
$("h1").addClass("big-title");

// $("button").text("Don't Click Me");
// $("button").html("Don't Click Me");

// $("h1").click(function() {
//     $("h1").css("font-size", "100px");
// });

// $("h1").click(function() {
//     $("h1").css("color", "red");
// });

//$("h1").css("color", "yellow");