var songArray = [
    {
        "id" : 1,
        "songName" : "Shape of You",
        "songUrl" : "songs/shapeofyou.mp3"
    },
    {
        "id" : 2,
        "songName" : "Shape of You",
        "songUrl" : "songs/shapeofyou.mp3"
    },
    {
        "id" : 3,
        "songName" : "Shape of You",
        "songUrl" : "songs/shapeofyou.mp3"
    },
    {
        "id" : 4,
        "songName" : "Shape of You",
        "songUrl" : "songs/shapeofyou.mp3"
    },
    {
        "id" : 5,
        "songName" : "Shape of You",
        "songUrl" : "songs/shapeofyou.mp3"
    }

]