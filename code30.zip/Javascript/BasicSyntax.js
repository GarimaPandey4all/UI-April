// window.addEventListener("load", function() {  // function() - anonymous function - no name of the function
// //Event Binding
// document.getElementById("btn").addEventListener('click', showName);
// });

window.addEventListener("load", initEvents);

function initEvents()
{
    console.log("Event Binding");
    document.getElementById("btn").addEventListener('click', showName);
}

function showName()
{
    console.log("Function Executed");
    var username = document.getElementById("box_1").value;
    //console.log(username);
    //document.getElementById("result").innerHTML += username;
    document.getElementById("result").innerHTML = username;
}